﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RTS_Task_1
{
    public partial class Form1 : Form
    {   
            Map m = new Map();

            public Form1()
            {
                InitializeComponent();
            }

            private void Form1_Load(object sender, EventArgs e)
            {
                Globals.m.initialiseMap();
            }

            private void btnStart_Click(object sender, EventArgs e)
            {

        }

        private void btnPause_Click(object sender, EventArgs e)
            {

        }

        #region Timer

        public void timer()
            {
                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        if (Globals.m.map[i, j] != " .")
                        {
                            Globals.GE.rules();
                        }
                    }
                }
            }

            int count;
            private void timer1_Tick(object sender, EventArgs e)
            {

        }
        #endregion



        static class Globals
        {
            public static Map m = new Map();
        

        }
    }
    }
}
