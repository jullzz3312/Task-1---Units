﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS_Task_1
{
    class Map
    {
        public string[,] map = new string[20, 20];
        public MeleeUnit[] closeCombat = new MeleeUnit[400];
        public RangedUnit[] rangedCombat = new RangedUnit[400];
        public List<MeleeUnit> mapUnitList = new List<MeleeUnit>();
        

        // Accessors

        public List<MeleeUnit> MapUnitList
        {
            get { return mapUnitList; }
        }

       


        public void initialiseMap()
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    map[i, j] = " .";
                }
            }
        }

        public string redraw()
        {
            string output = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    output += map[i, j];
                }
                output += Environment.NewLine;
            }
            return output;
        }

        public void warzone()
        {
            int skip = 0;
            int skip2 = 0;

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    Random rnd = new Random();
                    int xPos = rnd.Next(0, 20);
                    int yPos = rnd.Next(0, 20);
                    int unitChoice = rnd.Next(0, 3);
                    int teamChoice = rnd.Next(0, 3);



                    if ((unitChoice) % 2 == 0)
                    {
                        if ((teamChoice) % 2 == 0)
                        {
                            closeCombat[skip] = new MeleeUnit(xPos, yPos, 100, 0, true, 1, "Red", "M", 1, "Soldier");
                            map[xPos, yPos] = "M ";
                            skip++;
                        }
                        else
                        {
                            closeCombat[skip2] = new MeleeUnit(xPos, yPos, 100, 0, false, 1, "Green", "m", 0, "Knight");
                            map[xPos, yPos] = "m ";
                            skip2++;
                        }
                    }

                    {
                        if ((teamChoice) % 2 == 0)
                        {
                            rangedCombat[skip] = new RangedUnit(xPos, yPos, 100, 0, true, 5, "Red", "R", 1, "Gunner");
                            map[xPos, yPos] = "R ";
                            skip++;
                        }

                        {
                            rangedCombat[skip2] = new RangedUnit(xPos, yPos, 100, 0, false, 5, "Green", "r", 0, "Archer");
                            map[xPos, yPos] = "r ";
                            skip2++;

                        }
                    }
                }
            }
        }

        public void moveUnit(int xPos, int yPos, int XPos, int YPos)
        {
            string temp = "";
            temp = map[xPos, yPos];
            map[xPos, yPos] = " .";
            map[XPos, YPos] = temp;
        }

        public void updatePosition(int xPos, int yPos, int XPos, int YPos)
        {
            redraw();
            warzone();

        }
    }
}
