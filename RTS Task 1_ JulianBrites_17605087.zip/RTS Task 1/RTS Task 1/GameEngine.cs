﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS_Task_1
{
    class GameEngine
    {
        public void rules()
        {
            int unitNumber;
            int closestXPos;
            int closestYPos;

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    if (Globals.m.map[i, j] != ". ")
                    {
                        if (Globals.m.map[i, j] == "M ")
                        {



                        }

                    }
                }
            }
        }
    }
}
